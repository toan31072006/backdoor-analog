"""Separate NAD pose adaptation for five completed CEI A1 defense cells.

Reuses the frozen 3080 Ti source checkpoint/data receipts and native NAD
operator. No edits to that checkout, original victims, NC or historical tables.
Prepare only measures real-TRAIN B32 capacity; Run is an explicit serial phase.
"""
from __future__ import annotations

import argparse
import copy
from contextlib import contextmanager
import csv
import gc
import hashlib
import importlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

PROFILE = "EXPLORATORY_nad_pose_s42_3080ti_v2"
OUTPUT_FOLDER = "nad_pose_s42_3080ti_v2"
PAIRS = (("mmfi", "hpeli"), ("mmfi", "metafiplusplus"), ("mmfi", "wiflow"),
         ("piw3d", "hpeli"), ("piw3d", "wiflow"))
LAYERS = {"hpeli": ["skunit1", "skunit2", "regression.5"],
          "metafiplusplus": ["bn2", "tf", "decode.2"],
          "wiflow": ["residual_blocks.3", "att", "final_conv.2"]}
METRICS = ("t_mpjpe_mm", "target_pck_pct", "clean_mpjpe_mm", "clean_pampjpe_mm",
           "clean_target_mpjpe_mm", "triggered_gt_mpjpe_mm",
           "triggered_gt_minus_clean_target_mm", "mean_positive_dce_mm")


def sha(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(4 * 1024**2), b""):
            h.update(block)
    return h.hexdigest()


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"),
                                     allow_nan=False).encode()).hexdigest()


def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def write_new(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x", encoding="utf-8") as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write("\n")


@contextmanager
def lock(out):
    out.mkdir(parents=True, exist_ok=True)
    path = out / "nad.lock"
    with path.open("x", encoding="utf-8") as stream:
        stream.write(str(os.getpid()))
    try:
        yield
    finally:
        if path.read_text() == str(os.getpid()):
            path.unlink()


def boot(repo):
    sys.path[:0] = [str(repo / "remote_linux/defense_3080ti"), str(repo / "ATKBackd")]
    modules = {name: importlib.import_module(name) for name in
               ("run_mmfi", "run_piw", "collect", "gpu_smoke", "controller")}
    for name, m in modules.items():
        if not Path(m.__file__).resolve().is_relative_to(repo):
            raise ValueError(f"Wrong frozen module imported: {name}")
    return modules


def nad_recipe(backbone):
    from vast_seed42_defense_adapter import recipe
    result = recipe(backbone, "nad")
    if (result["nad_layers"] != LAYERS[backbone]
            or result["nad_teacher_epochs"] != 10 or result["nad_student_epochs"] != 10
            or result["nad_betas"] != [500., 1000., 1000.] or result["attention_p"] != 2.
            or result["lr"] != .01 or result["epochs"] != 100
            or result["momentum"] != .9 or result["weight_decay"] != .0005):
        raise ValueError("Frozen NAD recipe changed; no retuning")
    return result


def hardware(m):
    h = m["gpu_smoke"].hardware()
    driver = subprocess.run(["nvidia-smi", "--query-gpu=driver_version", "--format=csv,noheader"],
                            capture_output=True, text=True, check=True, timeout=20).stdout.strip()
    return dict(h, driver=driver)


def resolve_mmfi_home(args):
    """Use the sealed historical data root, not a possibly partial default copy.

    The frozen MM-Fi verifier checks files at the receipt's own root. It does
    not prove that a separately supplied data-home names that same dataset.
    Resolve this before binding/preparing the new sidecar; never edit the old
    receipt or silently redirect an explicit user override.
    """
    folder = args.base / "runs/mmfi_light_defense_s42_3080ti_v1"
    prepare = read(folder / "prepare.json")
    data = read(folder / "dataset_content.json")
    if (prepare.get("receipt_sha256") != digest({k:v for k,v in prepare.items() if k != "receipt_sha256"})
            or data.get("binding_sha256") != digest({k:v for k,v in data.items() if k != "binding_sha256"})
            or prepare.get("dataset_binding_sha256") != data.get("binding_sha256")):
        raise ValueError("Historical MM-Fi dataset/prepare receipt binding differs")
    home = Path(data["data_home"])
    if (not home.is_absolute() or home.resolve() != home
            or data.get("root") != str(home / "datasets/Compress")
            or data.get("splits", {}).get("train", {}).get("n") != 133056
            or data.get("splits", {}).get("eval", {}).get("n") != 33264):
        raise ValueError("Historical MM-Fi receipt must bind full P1S1 TRAIN/TEST and canonical root")
    if args.data_home is not None and args.data_home != home:
        raise ValueError(f"Explicit --data-home differs from historical FT: supplied={args.data_home}; recorded={home}")
    args.data_home = home
    print(f"MMFI_DATA_HOME_FROM_HISTORICAL_RECEIPT={home}", flush=True)


def validate_mmfi_train(train, bank):
    """Check full identities before attempting any clean-bank partition."""
    from run_peak_confirmation import _pair_ids
    from defend.a1_defense_eval import select_clean_bank
    ids = _pair_ids(train)
    count, sequences = len(ids), len({row[1] for row in ids})
    root = getattr(train, "data_root", None)
    if len(train) != 133056 or count != 133056 or sequences != 448:
        raise ValueError(f"NAD requires full historical MM-Fi TRAIN: got {len(train)} samples, "
                         f"{count} IDs, {sequences} sequences at {root}; expected 133056/133056/448. "
                         "No bank resampling or training performed.")
    if bank.get("counts", {}).get("train") != count or bank.get("pair_ids_sha256") != digest(ids):
        raise ValueError("NAD TRAIN identities/order differ from the historical FT bank")
    if bank != select_clean_bank(ids, 42, .05, .2):
        raise ValueError("NAD and existing FT trusted TRAIN banks differ")
    print(f"NAD_TRAIN_MATCH_FT n={count} sequences={sequences} "
          f"bank={bank['counts']['bank']} fit={bank['counts']['fit']} "
          f"selection={bank['counts']['selection']}", flush=True)


def bind(args, m, hw):
    """Reuse original content audits; only cached-file/stat and source checks."""
    mmfi = m["run_mmfi"].verify_receipt(args.base, args.data_home, args.repo)
    piw = m["run_piw"].verify_receipt(args.base, args.piw3d_root, args.repo)
    old = {"mmfi": mmfi, "piw3d": piw}
    cells = {}
    for dataset, backbone in PAIRS:
        # Require the existing no-defense result AND the original trusted bank.
        none, _ = m["collect"].load_record(args.base, dataset, backbone, "none")
        ft, _ = m["collect"].load_record(args.base, dataset, backbone, "ft")
        if not none or not ft or none["status"] != "complete" or ft["status"] != "complete":
            raise ValueError(f"Missing complete NoDef/FT source row: {dataset}/{backbone}")
        root = m["collect"].folder(args.base, dataset) / backbone
        cells[f"{dataset}/{backbone}"] = dict(recipe=nad_recipe(backbone),
            source_checkpoint_sha256=old[dataset]["cells"][backbone]["a1"]["checkpoint_sha256"],
            prepare_sha256=old[dataset]["receipt_sha256"],
            nodef_record_sha256=sha(root / "none/evaluation.json"),
            test_ids_sha256=none["test_ids_sha256"],
            clean_bank_sha256=sha(root / "ft/clean_bank.json"))
    return dict(schema=1, profile=PROFILE, seed=42, hardware=hw, script_sha256=sha(__file__),
                repo=str(args.repo), data_home=str(args.data_home), piw3d_root=str(args.piw3d_root),
                max_gpu_workers=1, physical_batch=32, cells=cells,
                scope="A1-only one-seed exploratory adaptation; not the completed multi-attack paper table")


def original_bank(args, m, dataset, backbone):
    path = m["collect"].folder(args.base, dataset) / backbone / "ft/clean_bank.json"
    return read(path)


def model_and_loaders(args, m, dataset, backbone, cell):
    from defend.a1_defense_eval import clean_loaders
    bank = original_bank(args, m, dataset, backbone)
    if dataset == "mmfi":
        from train_backdoor import _load_dataset
        model, source_cfg, trigger_state = m["run_mmfi"].model_from_checkpoint(
            args.base, backbone, "a1", cell["source_checkpoint_sha256"])
        cfg = m["run_mmfi"].local_cfg(source_cfg, args.data_home)
        train = _load_dataset(cfg, "training")
        validate_mmfi_train(train, bank)
        fit, selection = clean_loaders(train, bank, cfg, 42, batch_size=32)
        evaluation = dict(cfg=cfg, trigger_state=trigger_state)
    else:
        model, _ = m["run_piw"].load_model(args.base, backbone, "a1", cell["source_checkpoint_sha256"])
        train, _ = m["run_piw"].datasets(args.piw3d_root)
        fit, selection = m["run_piw"].clean_loaders(train, bank)
        evaluation = {}
    return model, fit, selection, bank, evaluation


def smoke_nad(model, batch, layers, *, device="cuda:0", physical_batch=32):
    """Real teacher update + frozen-teacher student update, never saves weights."""
    import torch
    from defend.a1_repair_ops import _batch, _state, pose_prediction, pose_loss, attention_loss
    initial = _state(model)
    model = model.to(device).train()
    x, y = _batch(batch, device)
    if len(x) != physical_batch:
        raise ValueError("NAD smoke requires the declared physical batch")
    optimizer = torch.optim.SGD(model.parameters(), lr=.01, momentum=.9, weight_decay=.0005)
    optimizer.zero_grad(set_to_none=True)
    teacher_loss = pose_loss(pose_prediction(model, x), y)
    teacher_loss.backward()
    optimizer.step()
    teacher = copy.deepcopy(model).eval().requires_grad_(False)
    model.load_state_dict(initial, strict=True)
    del initial, optimizer
    sf, tf, counts, handles = {}, {}, {}, []
    try:
        for role, net, features in (("student", model, sf), ("teacher", teacher, tf)):
            for layer in layers:
                key = (role, layer)
                counts[key] = 0
                def capture(_module, _args, output, *, key=key, features=features, layer=layer):
                    counts[key] += 1
                    if not isinstance(output, torch.Tensor) or output.ndim != 4:
                        raise ValueError("NAD hook must emit a fused BxCxHxW feature")
                    features[layer] = output
                handles.append(net.get_submodule(layer).register_forward_hook(capture))
        optimizer = torch.optim.SGD(model.parameters(), lr=.01, momentum=.9, weight_decay=.0005)
        optimizer.zero_grad(set_to_none=True)
        task = pose_loss(pose_prediction(model, x), y)
        with torch.no_grad():
            pose_prediction(teacher, x)
        if any(n != 1 for n in counts.values()):
            raise ValueError("NAD hook called repeatedly; per-antenna feature mapping is invalid")
        loss = task + sum(b * attention_loss(sf[n], tf[n]) for n, b in zip(layers, (500., 1000., 1000.)))
        if not torch.isfinite(loss) or not torch.isfinite(teacher_loss):
            raise ValueError("Nonfinite NAD capacity loss")
        loss.backward()
        if any(p.grad is not None for p in teacher.parameters()):
            raise ValueError("NAD teacher unexpectedly received gradients")
        optimizer.step()
        return dict(finite=True, physical_batch=physical_batch, teacher_optimizer_steps=1,
                    student_optimizer_steps=1, teacher_frozen=True, real_train_input=True,
                    teacher_loss=float(teacher_loss.detach()), student_loss=float(loss.detach()),
                    feature_shapes={k: list(v.shape) for k, v in sf.items()})
    finally:
        for h in handles:
            h.remove()


def prepare(args, m, plan):
    import torch
    for dataset, backbone in PAIRS:
        name = f"{dataset}/{backbone}"
        path = args.out / dataset / backbone / "smoke.json"
        binding = digest(dict(plan_sha256=plan["plan_sha256"], cell=name))
        if path.exists():
            r = read(path)
            validate_smoke(r, binding)
            continue
        m["controller"].initial_compute_check()
        m["run_mmfi"].seed_execution()
        model, fit, selection, bank, evaluation = model_and_loaders(args, m, dataset, backbone, plan["cells"][name])
        torch.cuda.reset_peak_memory_stats()
        result = smoke_nad(model, next(iter(fit)), LAYERS[backbone])
        torch.cuda.synchronize()
        result.update(binding_sha256=binding, peak_reserved_bytes=torch.cuda.max_memory_reserved(),
                      capacity_only=True, efficacy_verified=False)
        write_new(path, result)
        print(f"NAD_SMOKE_PASS {name} B32 peak={result['peak_reserved_bytes']/2**30:.2f}GiB", flush=True)
        del model, fit, selection, bank, evaluation
        gc.collect(); torch.cuda.empty_cache()
    gate = dict(plan_sha256=plan["plan_sha256"], smokes={
        f"{d}/{b}": sha(args.out / d / b / "smoke.json") for d, b in PAIRS})
    path = args.out / "prepared.json"
    if path.exists():
        if read(path) != gate:
            raise ValueError("Prepared gate changed")
    else:
        write_new(path, gate)
    print("PREPARED_NAD_ONLY; no full repair or TEST inference. Invoke --mode run separately.", flush=True)


def validate_smoke(r, binding):
    if (r.get("binding_sha256") != binding or r.get("finite") is not True
            or r.get("physical_batch") != 32 or r.get("teacher_frozen") is not True
            or r.get("real_train_input") is not True or r.get("capacity_only") is not True
            or r.get("teacher_optimizer_steps") != 1 or r.get("student_optimizer_steps") != 1
            or r.get("peak_reserved_bytes", 0) <= 0):
        raise ValueError("NAD smoke evidence is incomplete or differently bound")


def gate(args, plan):
    expected = dict(plan_sha256=plan["plan_sha256"], smokes={
        f"{d}/{b}": sha(args.out / d / b / "smoke.json") for d, b in PAIRS})
    if read(args.out / "prepared.json") != expected:
        raise ValueError("Prepare NAD successfully before Run")
    for d, b in PAIRS:
        binding = digest(dict(plan_sha256=plan["plan_sha256"], cell=f"{d}/{b}"))
        validate_smoke(read(args.out / d / b / "smoke.json"), binding)


def replay_metrics(folder, result, dataset):
    """Check complete six-dose sample errors; MM-Fi PA remains an inherited scalar."""
    import numpy as np
    n, width, joints = (33264, 17, [2, 3]) if dataset == "mmfi" else (2586, 14, [11, 13])
    with np.load(folder / "per_sample.npz", allow_pickle=False) as a:
        clean, target, gt, dce, scale = [a[k] for k in
            ("clean_error_mm", "target_error_mm", "triggered_gt_error_mm", "dce_error_mm", "clean_scale_mm")]
        if (clean.shape != (n, width) or target.shape != (n, 6, 2) or gt.shape != (n, 6, 2)
                or dce.shape != ((n, 6) if dataset == "mmfi" else (n, 6, 2)) or scale.shape != (n,)
                or a["pair_ids"].shape != (n, 3) or not np.array_equal(a["sample_indices"], np.arange(n))
                or not np.array_equal(a["doses"], [0., .2, .4, .6, .8, 1.])):
            raise ValueError("Partial NAD TEST or invalid paired-array geometry")
        ids = [[str(x), str(y), int(i)] for x, y, i in a["pair_ids"].tolist()]
        if digest(ids) != result.get("test_ids_sha256") or len(set(map(tuple, ids))) != n:
            raise ValueError("NAD ordered TEST identities differ or duplicate")
        for v in (clean, target, gt, dce, scale):
            if not np.isfinite(v).all() or (v < 0).any():
                raise ValueError("Invalid NAD distance array")
        if (scale <= 0).any() or not np.allclose(dce[:, 0], 0., atol=.002, rtol=0):
            raise ValueError("Invalid NAD PCK scale/dose-zero DCE")
        if (not np.allclose(target[:, 0], clean[:, joints], atol=.002, rtol=0)
                or not np.allclose(gt[:, 0], clean[:, joints], atol=.002, rtol=0)):
            raise ValueError("NAD dose-zero errors differ from clean target-joint errors")
        computed = dict(t_mpjpe_mm=float(target[:, -1].mean()),
            target_pck_pct=float((target[:, -1] <= .2 * scale[:, None]).mean()*100),
            clean_mpjpe_mm=float(clean.mean()), clean_target_mpjpe_mm=float(clean[:, joints].mean()),
            triggered_gt_mpjpe_mm=float(gt[:, -1].mean()),
            triggered_gt_minus_clean_target_mm=float(gt[:, -1].mean()-clean[:, joints].mean()),
            mean_positive_dce_mm=float(dce[:, 1:].mean()))
        if dataset == "piw3d":
            from eval.metrics import pa_mpjpe
            if a["truth"].shape != (n, 14, 3) or a["predictions"].shape != (n, 6, 14, 3):
                raise ValueError("Partial NAD PiW raw pose arrays")
            computed["clean_pampjpe_mm"] = float(pa_mpjpe(a["predictions"][:, 0], a["truth"]).mean()*1000)
    for key in METRICS:
        value = result["metrics"][key]
        if isinstance(value, bool) or not isinstance(value, (int, float)) or not np.isfinite(value):
            raise ValueError(f"Invalid NAD metric: {key}")
        if key != "triggered_gt_minus_clean_target_mm" and value < 0:
            raise ValueError(f"Negative NAD distance: {key}")
        if key in computed and abs(value-computed[key]) > 1e-7:
            raise ValueError(f"NAD metric does not replay: {key}")


def validate_result(args, plan, dataset, backbone):
    path = args.out / dataset / backbone / "evaluation.json"
    if not path.exists():
        return None
    r = read(path)
    if (r.get("profile") != PROFILE or r.get("plan_sha256") != plan["plan_sha256"]
            or r.get("dataset") != dataset or r.get("backbone") != backbone
            or r.get("method") != "nad" or r.get("status") != "complete"
            or r.get("record_sha256") != digest({k:v for k,v in r.items() if k != "record_sha256"})
            or set(r.get("artifacts", {})) != {"repair.pt", "per_sample.npz", "clean_bank.json"}):
        raise ValueError("NAD evaluation source binding/record differs")
    for name, checksum in r["artifacts"].items():
        if sha(path.parent / name) != checksum:
            raise ValueError("NAD evaluation artifact changed")
    repair = r.get("repair", {})
    if (repair.get("complete") is not True or repair.get("defense") != "nad" or r.get("seed") != 42
            or r.get("source_checkpoint_sha256") != plan["cells"][f"{dataset}/{backbone}"]["source_checkpoint_sha256"]
            or r.get("test_ids_sha256") != plan["cells"][f"{dataset}/{backbone}"]["test_ids_sha256"]
            or any(repair.get("stage_results", {}).get(stage, {}).get("selected_epoch") != 9
                   for stage in ("teacher", "student"))):
        raise ValueError("NAD did not complete both stages")
    replay_metrics(path.parent, r, dataset)
    return r


def run_cell(args, m, plan, dataset, backbone):
    import numpy as np
    import torch
    from defend.a1_repair_ops import train_repair
    cached = validate_result(args, plan, dataset, backbone)
    if cached:
        print(f"CACHED_COMPLETE {dataset}/{backbone}", flush=True)
        return cached
    m["controller"].initial_compute_check()
    cell = plan["cells"][f"{dataset}/{backbone}"]
    m["run_mmfi"].seed_execution()
    model, fit, selection, bank, ev = model_and_loaders(args, m, dataset, backbone, cell)
    folder = args.out / dataset / backbone
    if (folder / "per_sample.npz").exists():
        raise ValueError("Unreported NAD prediction file exists; preserve it and inspect")
    bank_path = folder / "clean_bank.json"
    if bank_path.exists():
        if read(bank_path) != bank:
            raise ValueError("NAD saved trusted bank differs")
    else:
        write_new(bank_path, bank)
    binding = digest(dict(plan_sha256=plan["plan_sha256"], cell=f"{dataset}/{backbone}"))
    print(f"NAD_REPAIR {dataset}/{backbone}: source A1 -> teacher10 -> original-A1 student10; TEST deferred", flush=True)
    model, repair = train_repair(model, fit, selection, "nad", cell["recipe"], "cuda:0",
                                 folder / "repair.pt", binding, 42)
    if repair.get("complete") is not True:
        raise ValueError("NAD incomplete; no TEST evaluation")
    if dataset == "mmfi":
        from train_backdoor import _load_dataset
        from eval_a1_target_pck import _restore_trigger
        from defend.a1_defense_eval import evaluate_defense
        from defend.a1_defense_metrics import enrich_evaluation
        from run_peak_confirmation import _pair_ids
        test = _load_dataset(ev["cfg"], "test")
        trigger = _restore_trigger(ev["cfg"], ev["trigger_state"])
        measured = enrich_evaluation(evaluate_defense(model, test, trigger, ev["cfg"], "cuda:0"))
        ids = _pair_ids(test)
        measured["arrays"]["pair_ids"] = np.asarray(ids, dtype=str)
    else:
        from piw_v2_adapter import build_trigger
        _, test = m["run_piw"].datasets(args.piw3d_root)
        measured = m["run_piw"].evaluate(model, test, build_trigger(args.base / "actions/data_bend.npy"))
        ids = m["run_piw"].pair_ids(test)
    if digest(ids) != cell["test_ids_sha256"]:
        raise ValueError("NAD TEST identities/order differ from paired original NoDef")
    npz = folder / "per_sample.npz"
    if npz.exists():
        raise ValueError("Unreported NAD prediction file exists; preserve it, do not silently retry")
    with npz.open("xb") as stream:
        np.savez_compressed(stream, **measured.pop("arrays"))
    measured.update(profile=PROFILE, plan_sha256=plan["plan_sha256"], dataset=dataset,
        backbone=backbone, method="nad", status="complete", seed=42, repair=repair,
        source_checkpoint_sha256=cell["source_checkpoint_sha256"], test_ids_sha256=digest(ids),
        artifacts={n:sha(folder/n) for n in ("repair.pt", "per_sample.npz", "clean_bank.json")})
    measured["record_sha256"] = digest(measured)
    write_new(folder / "evaluation.json", measured)
    print(f"NAD_EVALUATION_COMPLETE {dataset}/{backbone} {measured['metrics']}", flush=True)
    del model, fit, selection, test
    gc.collect(); torch.cuda.empty_cache()
    return measured


def collect(args, m, plan):
    """New summary only; historical NC remains diagnostic-only, never relabeled."""
    rows = []
    old = m["collect"]
    for dataset, backbone in PAIRS:
        for method in (*m["run_mmfi"].ROWS, "nad"):
            r = validate_result(args, plan, dataset, backbone) if method == "nad" else old.load_record(args.base, dataset, backbone, method)[0]
            row = dict(dataset=dataset, backbone=backbone, method=method,
                       status="pending" if r is None else r["status"])
            if r is not None and r["status"] == "complete":
                row.update({k:r["metrics"][k] for k in METRICS})
            rows.append(row)
    folder = args.out / "summary"
    folder.mkdir(exist_ok=True)
    value = dict(profile=PROFILE, plan_sha256=plan["plan_sha256"], rows=rows,
                 nad_complete=sum(r["method"] == "nad" and r["status"] == "complete" for r in rows),
                 metric_rows=sum("t_mpjpe_mm" in r for r in rows),
                 scope="A1-only seed42; NC diagnostic-only is not a repaired model")
    labels = dict(old.LABELS, nad="NAD adapted")
    lines = ["# CEI light defenses plus NAD adapted", "",
             "One seed/A1-only; teacher10+student10, source NAD LR schedule, B32.",
             "NAD uses more compute than FT10. Original results/checkpoints unchanged.", ""]
    for dataset, backbone in PAIRS:
        lines += [f"## {dataset} / {backbone}", "",
            "| Defense | Status | T-MPJPE | Target-PCK % | Clean all | Clean PA | Clean target2 | Triggered-GT target2 | Recovery gap | DCE |",
            "|---|---|---:|---:|---:|---:|---:|---:|---:|---:|"]
        for r in rows:
            if (r["dataset"], r["backbone"]) == (dataset, backbone):
                lines.append("| " + " | ".join([labels[r["method"]], r["status"],
                    *[f'{r[k]:.2f}' if k in r else "--" for k in METRICS]]) + " |")
        lines.append("")
    for name, text in (("defense_results.json", json.dumps(value, indent=2, allow_nan=False)),
                       ("defense_results.md", "\n".join(lines))):
        tmp = folder / (name + ".saving")
        with tmp.open("x", encoding="utf-8") as stream:
            stream.write(text)
        os.replace(tmp, folder / name)
    tmp = folder / "defense_results.csv.saving"
    with tmp.open("x", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=["dataset", "backbone", "method", "status", *METRICS])
        writer.writeheader(); writer.writerows(rows)
    os.replace(tmp, folder / "defense_results.csv")
    print(f"REPORT={folder} NAD={value['nad_complete']}/5", flush=True)
    return rows


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base", type=Path, default=Path("/media/jackson/Data/wificsi/defense_s42_3080ti"))
    parser.add_argument("--repo", type=Path)
    parser.add_argument("--data-home", type=Path,
                        help="Default: the data home sealed in the existing MM-Fi FT receipt")
    parser.add_argument("--piw3d-root", type=Path, default=Path("/media/jackson/Data/wificsi/piw3d"))
    parser.add_argument("--mode", choices=("prepare", "run", "status", "collect"), default="status")
    args = parser.parse_args(argv)
    args.repo = args.repo or args.base / "code/defense3080ti_v1/backdoor-analog"
    for name in ("base", "repo", "data_home", "piw3d_root"):
        value = getattr(args, name)
        if value is None:
            continue
        p = value.absolute()
        if p.resolve() != p:
            raise ValueError(f"Linked path refused: {p}")
        setattr(args, name, p)
    args.out = args.base / "runs" / OUTPUT_FOLDER
    if args.mode == "status":
        for d, b in PAIRS:
            p = args.out / d / b / "evaluation.json"
            print(d, b, read(p).get("status") if p.exists() else "pending")
        return 0
    os.environ.update(OMP_NUM_THREADS="2", MKL_NUM_THREADS="2", MKL_THREADING_LAYER="SEQUENTIAL",
                      PYTHONUNBUFFERED="1", PYTHONDONTWRITEBYTECODE="1")
    m = boot(args.repo)
    with lock(args.out):
        path = args.out / "plan.json"
        if args.mode == "collect":
            plan = read(path)
            if plan.get("profile") != PROFILE or plan.get("plan_sha256") != digest({k:v for k,v in plan.items() if k != "plan_sha256"}):
                raise ValueError("Invalid saved NAD plan")
            collect(args, m, plan)
            return 0
        resolve_mmfi_home(args)
        m["controller"].initial_compute_check()
        hw = hardware(m)
        plan = bind(args, m, hw)
        plan["plan_sha256"] = digest(plan)
        if path.exists():
            if read(path) != plan:
                raise ValueError("NAD code/runtime/data/source plan changed; no resume")
        elif args.mode == "prepare":
            write_new(path, plan)
        else:
            raise ValueError("Run Prepare first")
        if shutil.disk_usage(args.base).free < 8 * 2**30:
            raise ValueError("Require 8 GiB free for five independent NAD checkpoints; nothing deleted")
        if args.mode == "prepare":
            prepare(args, m, plan)
            return 0
        gate(args, plan)
        for d, b in PAIRS:
            run_cell(args, m, plan, d, b)
            collect(args, m, plan)
        print("NAD_5_OF_5_COMPLETE; independent repaired models; full six-dose TEST; summary exported.", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
