"""Six PiW3D MetaFi++ baselines matching the fresh DT-Pose Clean/A1 recipe.

The Clean/A1 victims remain in their immutable two-cell run. Baselines train
under a separate plan and are evaluated against that exact Clean checkpoint
only after a cross-plan source/data/recipe audit.
"""
from __future__ import annotations

import json
from pathlib import Path
import sys

import numpy as np

import run_piw_two_models_attacks as worker
from piw_v2_adapter import measure_predictions, target_pose


PROFILE = 'piw3d_metafi_dtpose_s42_baseline_six_v1'
METHODS = ('wanet_source', 'ftrojan', 'fiba', 'bpp_source',
           'smooth_lf_csi', 'tsba_adapted')
SHARED_SOURCES = tuple(worker.SOURCE_NAMES)
DEFAULT_REFERENCE = Path('/workspace/runs/piw3d_metafi_dtpose_s42_clean_a1_v1')

worker.PROFILE = PROFILE
worker.BACKBONES = ('metafiplusplus',)
worker.METHODS = METHODS
worker.BASELINES = METHODS
worker.SOURCE_NAMES += ('run_piw_metafi_dtpose_baseline_six.py',)
worker.RECIPES = {
    'metafiplusplus': dict(optimizer='adamw', lr=.01, weight_decay=.01,
                          accumulation=1, effective_batch=32),
}

_original_cfg_for = worker.cfg_for


def cfg_for(dataset_root, outdir, action_npy=None):
    cfg = _original_cfg_for(dataset_root, outdir, action_npy)
    cfg['model_initialization'] = 'torchvision ResNet34 IMAGENET1K_V1 then metafi_init'
    cfg['source_recipe'] = 'DT-Pose PiW3D MetaFi++ AdamW lr=0.01, default wd=0.01, B32, 200 epochs'
    cfg['interpretation'] = ('Exploratory PiW3D MetaFi++ six adapted baseline attacks; '
                             'fresh pretrained initialization; fixed final199; '
                             'Clean/A1 are external source-bound controls')
    return cfg


def build(backbone, device):
    if backbone != 'metafiplusplus':
        raise ValueError('This profile is MetaFi++ only')
    from models.metafi_plus_plus_piw3d import MetaFiPlusPlusPiW3DNet
    return MetaFiPlusPlusPiW3DNet(pretrained=True).to(device)


worker.cfg_for = cfg_for
worker._build = build


def reference_binding(saved):
    import torch

    root = Path(__import__('os').environ.get('PIW_CLEAN_A1_REFERENCE', DEFAULT_REFERENCE)).resolve()
    clean_plan_path = root / 'plan.json'
    clean_path = root / 'attacks/metafiplusplus/seed42/clean/checkpoint.pt'
    a1_path = root / 'attacks/metafiplusplus/seed42/a1/checkpoint.pt'
    if not clean_plan_path.is_file() or not clean_path.is_file() or not a1_path.is_file():
        raise ValueError('Clean/A1 reference is not yet final or is missing')
    reference = json.loads(clean_plan_path.read_text(encoding='utf-8'))
    cfg, ref_cfg = saved['cfg'], reference['cfg']
    if (reference.get('profile') != 'piw3d_metafi_dtpose_s42_clean_a1_v1' or
            ref_cfg.get('methods') != ['clean', 'a1'] or
            ref_cfg.get('backbones') != ['metafiplusplus'] or
            ref_cfg.get('model_initialization') != cfg['model_initialization'] or
            ref_cfg.get('source_recipe') != cfg['source_recipe']):
        raise ValueError('Foreign Clean/A1 reference plan')
    for key in ('dataset_root', 'action_npy', 'seed', 'epochs', 'final_epoch',
                'batch_size', 'num_workers', 'drop_last', 'amp', 'target', 'rho',
                'attack_eps', 'eval_doses', 'recipes'):
        if ref_cfg.get(key) != cfg.get(key):
            raise ValueError(f'Clean/A1 reference differs in {key}')
    for name in SHARED_SOURCES:
        if reference['sources'].get(name) != saved['sources'].get(name):
            raise ValueError(f'Clean/A1 reference differs in scientific source {name}')
    if (reference['inputs']['fingerprint'] != saved['inputs']['fingerprint'] or
            reference['action_sha256'] != saved['action_sha256'] or
            reference['poison'] != saved['poison']):
        raise ValueError('Clean/A1 reference differs in data/action/poison plan')
    clean = torch.load(clean_path, map_location='cpu', weights_only=False)
    a1 = torch.load(a1_path, map_location='cpu', weights_only=False)
    for method, checkpoint in (('clean', clean), ('a1', a1)):
        if (checkpoint.get('profile') != reference['profile'] or
                checkpoint.get('backbone') != 'metafiplusplus' or
                checkpoint.get('method') != method or
                checkpoint.get('epoch') != 199 or
                checkpoint.get('plan_sha256') != reference['plan_sha256']):
            raise ValueError(f'Clean/A1 {method} checkpoint is not final or foreign')
    return dict(root=root, plan=reference, clean=clean, a1=a1,
                clean_path=clean_path, a1_path=a1_path)


def evaluate(saved, backbone, method, device):
    if backbone != 'metafiplusplus' or method not in METHODS:
        raise ValueError('Baseline evaluation cell is not in this profile')
    worker._require_all_final(saved)
    ref = reference_binding(saved)
    own = worker._checkpoint(saved, backbone, method, final=True)
    if own['execution'] != worker._execution(device):
        raise ValueError('Evaluation GPU/backend differs from baseline checkpoint')
    ds = worker._datasets(saved)
    x, truth, names = worker._test_arrays(ds['validation'])
    if names != saved['inputs']['splits']['test_data']['ordered_names']:
        raise ValueError('PiW TEST ordering changed')
    victim = build(backbone, device)
    victim.load_state_dict(own['model'], strict=True)
    clean = build(backbone, device)
    clean.load_state_dict(ref['clean']['model'], strict=True)
    trigger = worker.make_trigger(method, ds['training'], saved['cfg'])
    if method == 'tsba_adapted':
        trigger.load_state_dict(own['trigger'], strict=True)
        trigger = trigger.to(device)
    elif method in ('wanet_source', 'ftrojan', 'fiba', 'bpp_source'):
        trigger.load_state_dict(own['trigger'])
    doses = worker.DOSES
    victim_grid = worker._predict_grid(victim, x, trigger, doses, device)
    clean_grid = worker._predict_grid(clean, x, trigger, doses, device)
    metrics = measure_predictions(truth, victim_grid[:, 0], victim_grid,
                                  clean_grid[:, 0], clean_grid)
    targets = np.stack([target_pose(truth, d) for d in doses], axis=1)
    folder = worker.cell_dir(saved['cfg'], backbone, method)
    worker._atomic_npz(folder / 'predictions.npz', truth=truth,
                       names=np.asarray(names), doses=np.asarray(doses),
                       predictions=victim_grid[:, 0], trigger_predictions=victim_grid,
                       reference_predictions=clean_grid[:, 0],
                       reference_trigger_predictions=clean_grid, targets=targets)
    result = dict(profile=PROFILE, status='COMPLETE', backbone=backbone,
                  method=method, seed=42, plan_sha256=saved['plan_sha256'],
                  checkpoint_sha256=worker._sha(folder / 'checkpoint.pt'),
                  clean_plan_sha256=ref['plan']['plan_sha256'],
                  clean_checkpoint_sha256=worker._sha(ref['clean_path']),
                  a1_checkpoint_sha256=worker._sha(ref['a1_path']),
                  predictions_sha256=worker._sha(folder / 'predictions.npz'),
                  poison=own['poison'], metrics=metrics,
                  limitations=['One seed; no uncertainty estimate.',
                               'PiW digital CSI operators are dataset adaptations.',
                               'Clean/A1 are audited external controls, not retrained here.'])
    worker._atomic_json(folder / 'evaluation.json', result)
    print(f'EVAL_COMPLETE {backbone}__s42__{method}: {metrics["mainmetrics"]}', flush=True)


worker.evaluate_cell = evaluate


if __name__ == '__main__':
    try:
        raise SystemExit(worker.main())
    except (OSError, RuntimeError, ValueError, KeyError) as error:
        print(f'[PiW MetaFi DT-Pose baseline six] ERROR: {error}',
              file=sys.stderr, flush=True)
        raise SystemExit(1)
