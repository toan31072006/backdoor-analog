"""Build verified PiW3D MetaFi++ six-baseline code/weights ZIP."""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
from importlib.util import module_from_spec, spec_from_file_location
import json
from pathlib import Path
import subprocess
import sys
import zipfile


PROFILE = 'piw3d_metafi_dtpose_s42_baseline_six_v1'
WEIGHT_NAME = 'torch-cache/hub/checkpoints/resnet34-b627a593.pth'
EXTRAS = (
    'ATKBackd/run_piw_metafi_dtpose_baseline_six.py',
    'remote_linux/piw3d_metafi_dtpose/baseline_six_controller.py',
    'remote_linux/piw3d_metafi_dtpose/baseline_six_start.sh',
    'remote_tools/Build-PiW3DMetaFiDTPoseBaselineSixBundle.py',
)


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def build(repo: Path, weights: Path, output: Path) -> dict:
    repo, weights, output = repo.resolve(), weights.resolve(), output.resolve()
    if output.exists():
        raise FileExistsError(output)
    weight_bytes = weights.read_bytes()
    if not sha(weight_bytes).startswith('b627a593'):
        raise ValueError('Not official ResNet34 IMAGENET1K_V1 weights')
    spec = spec_from_file_location('piw_original_builder',
                                  repo / 'remote_tools/Build-PiW3DTwoModelsBundle.py')
    module = module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    payload = module.collect(repo)
    for name in EXTRAS:
        path = repo / name
        if not path.is_file() or path.is_symlink():
            raise FileNotFoundError(path)
        payload[name] = path.read_bytes()
    payload[WEIGHT_NAME] = weight_bytes
    commit = subprocess.run(['git', 'rev-parse', 'HEAD'], cwd=repo, check=True,
                            capture_output=True, text=True).stdout.strip()
    manifest = dict(schema=1, purpose=PROFILE,
                    created_utc=datetime.now(timezone.utc).isoformat(),
                    base_commit=commit, includes_dataset=False,
                    includes_action_prior=False, includes_checkpoints=False,
                    resnet34_weight_sha256=sha(weight_bytes),
                    files={name: dict(bytes=len(data), sha256=sha(data))
                           for name, data in sorted(payload.items())})
    payload['BUNDLE_MANIFEST.json'] = (
        json.dumps(manifest, indent=2, sort_keys=True) + '\n').encode()
    output.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(output, 'x', zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for name, data in sorted(payload.items()):
            archive.writestr('backdoor-analog/' + name, data)
    with zipfile.ZipFile(output) as archive:
        if archive.testzip() is not None:
            raise ValueError('ZIP CRC failed')
    digest = hashlib.sha256()
    with output.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
    return dict(path=str(output), sha256=digest.hexdigest(),
                bytes=output.stat().st_size, source_files=len(manifest['files']))


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path,
                        default=Path(__file__).resolve().parents[1])
    parser.add_argument('--weights', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    print(json.dumps(build(args.repo, args.weights, args.output), indent=2))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
