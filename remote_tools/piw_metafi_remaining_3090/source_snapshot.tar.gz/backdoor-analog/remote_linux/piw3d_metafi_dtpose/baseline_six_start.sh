#!/usr/bin/env bash
set -euo pipefail
HERE=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
REPO=$(cd -- "$HERE/../.." && pwd)
PYTHON_BIN=${PIW_PYTHON:-/venv/main/bin/python}
OUT=${PIW_OUTDIR:-/workspace/runs/piw3d_metafi_dtpose_s42_baseline_six_v1}
SESSION=piw3d-metafi-dtpose-baseline-six
ARGS=("$HERE/baseline_six_controller.py" --repo "$REPO" --out "$OUT")
case "${1:-}" in
  --dry-run) exec "$PYTHON_BIN" -u "${ARGS[@]}" dry-run ;;
  --prepare) exec "$PYTHON_BIN" -u "${ARGS[@]}" prepare ;;
  --status) exec "$PYTHON_BIN" -u "${ARGS[@]}" status ;;
  --launch)
    test -f "$OUT/prelaunch_gate.json"
    if tmux has-session -t "$SESSION" 2>/dev/null; then
      echo "Session already exists: $SESSION" >&2; exit 1
    fi
    printf -v QUOTED '%q ' "$PYTHON_BIN" -u "${ARGS[@]}" launch
    printf -v QUOTED_LOG '%q' "$OUT/controller.log"
    tmux new-session -d -s "$SESSION" "exec $QUOTED >> $QUOTED_LOG 2>&1"
    echo "STARTED $SESSION: six MetaFi++ baselines, max 3 compute jobs/GPU"
    echo "Monitor: tail -F $OUT/controller.log"
    ;;
  *) echo "Usage: bash $0 --dry-run|--prepare|--launch|--status" >&2; exit 2 ;;
esac
