"""Audited six-baseline MetaFi++ queue sharing two GPUs with existing PiW jobs."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time


PROFILE = 'piw3d_metafi_dtpose_s42_baseline_six_v1'
METHODS = ('tsba_adapted', 'ftrojan', 'fiba', 'wanet_source',
           'bpp_source', 'smooth_lf_csi')
SCIENTIFIC_SOURCES = (
    'run_piw_two_models_attacks.py', 'run_piw_hpeli_clean.py',
    'piw_v2_adapter.py', 'piw_a1_adapter.py', 'piw_native_attack_adapter.py',
    'piw_extra_attack_adapter.py', 'data_utils/feeder.py',
    'models/piw3d_two_models.py', 'models/metafi_plus_plus_piw3d.py',
    'models/wiflow_piw3d.py', 'models/piw3d_backbone_factory.py',
    'models/metafi_channel_transformer.py', 'models/metafi_plus_plus.py',
    'models/_vendor/wiflow_mmfi.py', 'attack/trigger.py',
    'attack/method_drafts.py', 'attack/wanet_source.py',
    'attack/frequency_baselines.py', 'attack/static_source_baselines.py',
    'attack/smooth_lf_csi.py', 'attack/tsba.py', 'eval/metrics.py',
)
REFERENCE = Path('/workspace/runs/piw3d_metafi_dtpose_s42_clean_a1_v1')


def sha(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def atomic_json(path: Path, record: dict) -> None:
    temp = path.with_suffix(path.suffix + '.saving')
    temp.write_text(json.dumps(record, indent=2, sort_keys=True) + '\n',
                    encoding='utf-8')
    temp.replace(path)


def verify_bundle(repo: Path) -> None:
    manifest = json.loads((repo / 'BUNDLE_MANIFEST.json').read_text(encoding='utf-8'))
    if manifest.get('purpose') != PROFILE:
        raise ValueError('Wrong MetaFi six-baseline bundle')
    for name, expected in manifest['files'].items():
        path = (repo / name).resolve()
        if not path.is_relative_to(repo) or not path.is_file() or path.is_symlink():
            raise ValueError(f'Missing source: {name}')
        if path.stat().st_size != expected['bytes'] or sha(path) != expected['sha256']:
            raise ValueError(f'Changed source: {name}')
    print(f'VERIFIED_BASELINE_BUNDLE {len(manifest["files"])} files', flush=True)


def gpu_counts() -> dict[str, int]:
    devices = subprocess.run(['nvidia-smi', '--query-gpu=uuid',
                              '--format=csv,noheader'], check=True,
                             capture_output=True, text=True).stdout.splitlines()
    apps = subprocess.run(['nvidia-smi', '--query-compute-apps=gpu_uuid,pid',
                           '--format=csv,noheader'], check=True,
                          capture_output=True, text=True).stdout.splitlines()
    counts = {f'cuda:{index}': 0 for index in range(len(devices))}
    if len(devices) != 2:
        raise RuntimeError(f'Expected 2 GPUs, found {len(devices)}')
    for line in apps:
        uuid = line.split(',', 1)[0].strip()
        if uuid in devices:
            counts[f'cuda:{devices.index(uuid)}'] += 1
    return counts


def gpu_processes() -> dict[str, set[int]]:
    devices = subprocess.run(['nvidia-smi', '--query-gpu=uuid',
                              '--format=csv,noheader'], check=True,
                             capture_output=True, text=True).stdout.splitlines()
    apps = subprocess.run(['nvidia-smi', '--query-compute-apps=gpu_uuid,pid',
                           '--format=csv,noheader'], check=True,
                          capture_output=True, text=True).stdout.splitlines()
    result = {f'cuda:{index}': set() for index in range(len(devices))}
    for line in apps:
        fields = [part.strip() for part in line.split(',')]
        if len(fields) >= 2 and fields[0] in devices and fields[1].isdigit():
            result[f'cuda:{devices.index(fields[0])}'].add(int(fields[1]))
    return result


def gpu_free_gib() -> dict[str, float]:
    lines = subprocess.run(['nvidia-smi', '--query-gpu=memory.free',
                            '--format=csv,noheader,nounits'], check=True,
                           capture_output=True, text=True).stdout.splitlines()
    return {f'cuda:{index}': float(value.strip()) / 1024
            for index, value in enumerate(lines)}


def available_memory_gib() -> float:
    for line in Path('/proc/meminfo').read_text().splitlines():
        if line.startswith('MemAvailable:'):
            return int(line.split()[1]) / (1024 * 1024)
    raise RuntimeError('Cannot read MemAvailable')


def command(args, *extra: str) -> list[str]:
    return [sys.executable, '-u',
            str(args.repo / 'ATKBackd/run_piw_metafi_dtpose_baseline_six.py'),
            '--dataset-root', str(args.dataset), '--action-npy', str(args.action),
            '--outdir', str(args.out), *extra]


def require_inputs(args) -> None:
    for path in (args.dataset / 'train_data/train_data_list.txt',
                 args.dataset / 'test_data/test_data_list.txt', args.action):
        if not path.is_file():
            raise FileNotFoundError(path)


def reference_audit(plan: dict) -> None:
    reference = json.loads((REFERENCE / 'plan.json').read_text(encoding='utf-8'))
    cfg, ref_cfg = plan['cfg'], reference['cfg']
    if (reference.get('profile') != 'piw3d_metafi_dtpose_s42_clean_a1_v1' or
            ref_cfg.get('methods') != ['clean', 'a1'] or
            ref_cfg.get('backbones') != ['metafiplusplus'] or
            ref_cfg.get('recipes') != cfg.get('recipes') or
            ref_cfg.get('model_initialization') != cfg.get('model_initialization') or
            ref_cfg.get('source_recipe') != cfg.get('source_recipe')):
        raise ValueError('Wrong Clean/A1 reference recipe')
    for key in ('dataset_root', 'action_npy', 'seed', 'epochs', 'final_epoch',
                'batch_size', 'num_workers', 'drop_last', 'amp', 'target',
                'rho', 'attack_eps', 'eval_doses', 'tsba', 'cover_ratios'):
        if ref_cfg.get(key) != cfg.get(key):
            raise ValueError(f'Clean/A1 reference differs in {key}')
    for name in SCIENTIFIC_SOURCES:
        if reference['sources'].get(name) != plan['sources'].get(name):
            raise ValueError(f'Scientific source differs from Clean/A1: {name}')
    if (reference['inputs']['fingerprint'] != plan['inputs']['fingerprint'] or
            reference['action_sha256'] != plan['action_sha256'] or
            reference['poison'] != plan['poison']):
        raise ValueError('Reference data/action/poison differs')
    print('REFERENCE_BINDING_PASS', reference['plan_sha256'], flush=True)


def gate(args) -> dict:
    plan = json.loads((args.out / 'plan.json').read_text(encoding='utf-8'))
    record = json.loads((args.out / 'prelaunch_gate.json').read_text(encoding='utf-8'))
    if (plan['profile'] != PROFILE or record.get('profile') != PROFILE or
            record['preflight']['plan_sha256'] != plan['plan_sha256'] or
            set(record['smoke']) != set(METHODS) or
            record['action_sha256'] != sha(args.action)):
        raise ValueError('Incomplete or foreign baseline prelaunch gate')
    reference_audit(plan)
    return record


def prepare(args) -> None:
    verify_bundle(args.repo)
    require_inputs(args)
    args.out.mkdir(parents=True, exist_ok=True)
    if (args.out / 'prelaunch_gate.json').is_file():
        gate(args)
        print('PREPARED_EXISTING; no training launched', flush=True)
        return
    print('Auditing full PiW3D input before baseline training...', flush=True)
    result = subprocess.run(command(args, '--preflight-only'),
                            capture_output=True, text=True)
    (args.out / 'preflight.log').write_text(
        result.stderr + '\n' + result.stdout, encoding='utf-8')
    if result.returncode:
        raise RuntimeError(f'Preflight failed: {args.out / "preflight.log"}')
    receipt = json.loads(result.stdout)
    if receipt['status'] not in ('PASS', 'PASS_EXISTING'):
        raise ValueError('Preflight did not pass')
    reference_audit(json.loads((args.out / 'plan.json').read_text(encoding='utf-8')))
    smokes = {}
    folder = args.out / 'smoke'
    folder.mkdir(exist_ok=True)
    for method in METHODS:
        while gpu_counts()['cuda:0'] >= 3 or available_memory_gib() < 24:
            print(f'WAIT_SMOKE_SLOT {method} {gpu_counts()}', flush=True)
            time.sleep(30)
        log = folder / f'{method}.log'
        with log.open('x', encoding='utf-8') as stream:
            code = subprocess.run(command(args, '--cell',
                f'metafiplusplus__s42__{method}', '--device', 'cuda:0',
                '--smoke-only'), stdout=stream, stderr=subprocess.STDOUT).returncode
        if code or 'GPU_SMOKE_WORKER_PASS' not in log.read_text(encoding='utf-8'):
            raise RuntimeError(f'GPU smoke failed ({code}): {log}')
        smokes[method] = dict(device='cuda:0', log_sha256=sha(log))
        print(f'SMOKE_PASS {method}', flush=True)
    atomic_json(args.out / 'prelaunch_gate.json',
                dict(schema=1, profile=PROFILE, preflight=receipt,
                     action_sha256=sha(args.action), smoke=smokes))
    gate(args)
    print('PREPARED_ONLY: six smokes passed; no full training', flush=True)


def checkpoint_epoch(args, method: str) -> int | None:
    path = args.out / 'attacks/metafiplusplus/seed42' / method / 'checkpoint.pt'
    if not path.is_file():
        return None
    import torch
    blob = torch.load(path, map_location='cpu', weights_only=False)
    plan = json.loads((args.out / 'plan.json').read_text(encoding='utf-8'))
    if (blob.get('profile') != PROFILE or blob.get('method') != method or
            blob.get('backbone') != 'metafiplusplus' or
            blob.get('plan_sha256') != plan['plan_sha256'] or
            not isinstance(blob.get('epoch'), int)):
        raise ValueError(f'Foreign checkpoint: {path}')
    return blob['epoch']


def placement(args) -> dict[str, str]:
    path = args.out / 'placements.json'
    return json.loads(path.read_text(encoding='utf-8')) if path.is_file() else {}


def start_job(args, method: str, device: str, phase: str):
    folder = args.out / 'logs' / phase
    folder.mkdir(parents=True, exist_ok=True)
    log = folder / f'{method}.{int(time.time())}.log'
    extra = ['--cell', f'metafiplusplus__s42__{method}', '--device', device]
    if phase == 'evaluate':
        extra.append('--evaluate-only')
    sink = log.open('x', encoding='utf-8')
    try:
        child = subprocess.Popen(command(args, *extra), stdout=sink,
                                 stderr=subprocess.STDOUT)
    finally:
        sink.close()
    print(f'[{phase}] {method} PID={child.pid} {device} log={log}', flush=True)
    return child, log


def train(args) -> None:
    gate(args)
    assigned = placement(args)
    pending = [method for method in METHODS if checkpoint_epoch(args, method) != 199]
    running = {}
    while pending or running:
        for method, (child, log, device) in list(running.items()):
            code = child.poll()
            if code is None:
                continue
            del running[method]
            if code or checkpoint_epoch(args, method) != 199:
                raise RuntimeError(f'{method} failed ({code}), no automatic retry: {log}')
            print(f'TRAIN_COMPLETE {method} {device}', flush=True)
        if pending:
            processes = gpu_processes()
            counts = {device: len(pids) + sum(
                1 for child, _, assigned_device in running.values()
                if assigned_device == device and child.poll() is None and child.pid not in pids)
                for device, pids in processes.items()}
            free = gpu_free_gib()
            if available_memory_gib() >= 24:
                method = pending[0]
                # Unfinished jobs may only move devices if no checkpoint exists.
                prior = assigned.get(method) if checkpoint_epoch(args, method) is not None else None
                choices = [prior] if prior else ['cuda:0', 'cuda:1']
                choices = [device for device in choices
                           if counts[device] < 3 and free[device] >= 6]
                if choices:
                    device = min(choices, key=lambda name: counts[name])
                    assigned[method] = device
                    atomic_json(args.out / 'placements.json', assigned)
                    child, log = start_job(args, method, device, 'train')
                    running[method] = (child, log, device)
                    pending.pop(0)
                    # Reserve capacity until the child becomes visible to nvidia-smi.
                    time.sleep(8)
                    continue
        if pending or running:
            time.sleep(20)


def evaluate(args) -> None:
    import torch
    for method in METHODS:
        if checkpoint_epoch(args, method) != 199:
            raise ValueError(f'{method} is not final199')
    print('All six baseline checkpoints are final199; waiting for Clean/A1 controls', flush=True)
    while True:
        clean = REFERENCE / 'attacks/metafiplusplus/seed42/clean/checkpoint.pt'
        a1 = REFERENCE / 'attacks/metafiplusplus/seed42/a1/checkpoint.pt'
        if clean.is_file() and a1.is_file():
            if all(torch.load(path, map_location='cpu', weights_only=False).get('epoch') == 199
                   for path in (clean, a1)):
                break
        time.sleep(60)
    for method in METHODS:
        folder = args.out / 'attacks/metafiplusplus/seed42' / method
        if (folder / 'evaluation.json').is_file():
            continue
        device = placement(args)[method]
        while gpu_counts()[device] >= 3 or available_memory_gib() < 24:
            time.sleep(30)
        child, log = start_job(args, method, device, 'evaluate')
        code = child.wait()
        if code or not (folder / 'evaluation.json').is_file():
            raise RuntimeError(f'{method} evaluation failed ({code}): {log}')
    print('METAFI_BASELINE_6_OF_6_COMPLETE', flush=True)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mode', choices=('dry-run', 'prepare', 'launch', 'status'))
    parser.add_argument('--repo', type=Path, required=True)
    parser.add_argument('--dataset', type=Path, default=Path(
        '/workspace/piw3d/datasets/Person-in-WiFi-3D_processed_v1'))
    parser.add_argument('--action', type=Path,
                        default=Path('/workspace/piw3d/actions/data_bend.npy'))
    parser.add_argument('--out', type=Path, default=Path(
        '/workspace/runs/piw3d_metafi_dtpose_s42_baseline_six_v1'))
    args = parser.parse_args()
    args.repo, args.dataset, args.action, args.out = (
        args.repo.resolve(), args.dataset.resolve(), args.action.resolve(),
        args.out.resolve())
    os.environ['TORCH_HOME'] = str(args.repo / 'torch-cache')
    if args.mode == 'status':
        print(json.dumps({method: dict(epoch=checkpoint_epoch(args, method),
            evaluated=(args.out / 'attacks/metafiplusplus/seed42' / method /
                       'evaluation.json').is_file(),
            device=placement(args).get(method)) for method in METHODS}, indent=2))
    elif args.mode == 'dry-run':
        verify_bundle(args.repo)
        subprocess.run(command(args, '--dry-run'), check=True)
    elif args.mode == 'prepare':
        prepare(args)
    else:
        verify_bundle(args.repo)
        require_inputs(args)
        gate(args)
        train(args)
        evaluate(args)


if __name__ == '__main__':
    try:
        main()
    except (OSError, RuntimeError, ValueError, KeyError,
            subprocess.CalledProcessError) as error:
        print(f'[MetaFi six-baseline controller] ERROR: {error}', file=sys.stderr,
              flush=True)
        raise SystemExit(1)
